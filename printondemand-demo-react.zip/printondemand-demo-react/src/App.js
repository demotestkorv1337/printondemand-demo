import React from "react";
import PrintOnDemandDemo from "./components/PrintOnDemandDemo";

export default function App() {
  return (
    <div>
      <PrintOnDemandDemo />
    </div>
  );
}
