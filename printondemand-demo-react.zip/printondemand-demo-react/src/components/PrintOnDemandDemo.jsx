import React, { useState } from "react";

export default function PrintOnDemandDemo() {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [product, setProduct] = useState("tshirt");
  const [size, setSize] = useState("M");
  const [price, setPrice] = useState(249);
  const [processing, setProcessing] = useState(false);

  const basePrices = {
    tshirt: 249,
    hoodie: 399,
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleProductChange = (e) => {
    const value = e.target.value;
    setProduct(value);
    setPrice(basePrices[value]);
  };

  const handleSubmit = async () => {
    setProcessing(true);
    setTimeout(() => {
      alert(`Beställning: ${product} (${size}) för ${price} kr. Bild bifogad.`);
      setProcessing(false);
    }, 1500);
  };

  return (
    <div style={{ maxWidth: 500, margin: "20px auto", padding: 20, fontFamily: "Arial, sans-serif" }}>
      <h1 style={{ fontSize: 24, fontWeight: "bold" }}>Ladda upp din design</h1>
      <div style={{ border: "1px solid #ccc", borderRadius: 8, padding: 16, marginTop: 16 }}>
        <div style={{ marginBottom: 16 }}>
          <label htmlFor="image" style={{ display: "block", marginBottom: 4 }}>Välj bild</label>
          <input type="file" id="image" accept="image/*" onChange={handleImageUpload} />
          {preview && (
            <div style={{ marginTop: 16 }}>
              <p style={{ marginBottom: 8, fontWeight: "600" }}>Förhandsvisning:</p>
              <div style={{ border: "1px solid #ccc", padding: 16, display: "inline-block" }}>
                <div style={{ width: 192, height: 192, backgroundColor: "#f0f0f0", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <img src={preview} alt="Preview" style={{ maxWidth: "100%", maxHeight: "100%" }} />
                </div>
              </div>
            </div>
          )}
        </div>

        <div style={{ marginBottom: 16 }}>
          <label htmlFor="product" style={{ display: "block", marginBottom: 4 }}>Välj produkt</label>
          <select id="product" value={product} onChange={handleProductChange} style={{ width: "100%", padding: 8, borderRadius: 4, border: "1px solid #ccc" }}>
            <option value="tshirt">T-shirt</option>
            <option value="hoodie">Hoodie</option>
          </select>
        </div>

        <div style={{ marginBottom: 16 }}>
          <label htmlFor="size" style={{ display: "block", marginBottom: 4 }}>Storlek</label>
          <select id="size" value={size} onChange={(e) => setSize(e.target.value)} style={{ width: "100%", padding: 8, borderRadius: 4, border: "1px solid #ccc" }}>
            <option value="S">S</option>
            <option value="M">M</option>
            <option value="L">L</option>
            <option value="XL">XL</option>
          </select>
        </div>

        <div style={{ fontSize: 18, fontWeight: "600", marginBottom: 16 }}>
          Pris: {price} kr
        </div>

        <button onClick={handleSubmit} disabled={processing} style={{ width: "100%", padding: 12, backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: 4, cursor: processing ? "not-allowed" : "pointer" }}>
          {processing ? "Bearbetar..." : "Beställ (demo)"}
        </button>
      </div>
    </div>
  );
}
